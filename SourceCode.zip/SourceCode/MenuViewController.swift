//
//  menuViewController.swift
//  WMPOC
//
//  Created by Rajeswari on 22/08/22.
//

import UIKit
enum SideMenuOneOptions : String, CaseIterable {
    case scanHistory = "Scan History"
    case instrumentInfo = "Instrument info"
    case syncHistory = "Sync history"
    case preferances = "Preferences"
}

enum SideMenuTwoOption: String, CaseIterable {
    case help = "Help"
    case requestSupport = "Request support"
    case appTour = "App tour"
    case logout = "Logout"
}

class MenuViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return section == 0 ? SideMenuOneOptions.allCases.count : SideMenuTwoOption.allCases.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 1 {
            let v = UIView(frame: CGRect(x: 0, y:0, width: tableView.frame.width, height: 30))
            let insertView = UIView(frame: CGRect(x: 0, y:0, width: tableView.frame.width, height: 2))
            insertView.backgroundColor = #colorLiteral(red: 0.7764705882, green: 0.7764705882, blue: 0.737254902, alpha: 1)
            v.addSubview(insertView)
            return v
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 30
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell =  tableView.dequeueReusableCell(withIdentifier: "MenuList") as! UITableViewCell//UITableViewCell(style: .default, reuseIdentifier: "MenuList")
        guard let customFont = UIFont(name: "NeoSansPro-Regular", size: UIFont.labelFontSize) else {
            fatalError("""
                Failed to load the "CustomFont-Light" font.
                Make sure the font file is included in the project and the font name is spelled correctly.
                """
            )
        }
        cell.textLabel?.font = customFont
        switch indexPath.section {
        case 0:
            cell.textLabel?.text = SideMenuOneOptions.allCases[indexPath.row].rawValue
            let chevron: UIImage = #imageLiteral(resourceName: "chevron")
            cell.accessoryType = .disclosureIndicator
            cell.accessoryView = UIImageView(image: chevron)
        case 1:
            cell.textLabel?.text = SideMenuTwoOption.allCases[indexPath.row].rawValue
            cell.accessoryType = .none
        default:
            break
        }
        return cell
    }
    

    @IBOutlet weak var menuTblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        menuTblView.delegate = self
        menuTblView.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
